<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2022 &copy; Agrapana</p>
        </div>
        <div class="float-end">
            <p>Build with <span class="text-danger"><i class="bi bi-heart"></i></span> in <a
                    href="https://saugi.me">Ciwaruga</a></p>
        </div>
    </div>
</footer>
