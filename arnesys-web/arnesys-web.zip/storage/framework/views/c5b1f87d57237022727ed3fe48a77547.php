<?php $__env->startSection('title', 'Fields'); ?>

<?php $__env->startSection('breadcrumb-content'); ?>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm">
                <a class="opacity-5 text-white" href="javascript:;">
                    Pages
                </a>
            </li>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Operator')): ?>
            <li class="breadcrumb-item text-sm text-white active" aria-current="page">
                <a class="opacity-5 text-white" href="<?php echo e(route('client')); ?>">
                    Client
                </a>
            </li>
            <?php endif; ?>
            <li class="breadcrumb-item text-sm text-white active" aria-current="page">
                Field
            </li>
        </ol>
        <h6 class="font-weight-bolder text-white mb-0">Field </h6>
    </nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row content-wrapper mt-3" style="padding-bottom: 70px;">
        <div class="col-xl-12 col-sm-12">
            <div class="row">
                <div class="col-12">
                    <div class="card pb-3">
                        <div class="card-header pb-0">
                            <h6>Fields Data</h6>
                        </div>
                        <div class="card-body px-0 pt-0 pb-2">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Plant Name
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Land Area
                                            </th>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Address
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-center">
                                                Number of Support Device
                                            </th>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Field Created
                                            </th>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Action
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex px-2 py-1">
                                                        <div>
                                                            <img
                                                                <?php if($row->thumbnail == NULL): ?>
                                                                    src="<?php echo e(asset('assets')); ?>/img/field.jpg"
                                                                <?php else: ?>
                                                                    src="<?php echo e(Storage::url($row->thumbnail)); ?>"
                                                                <?php endif; ?>
                                                                class="avatar avatar-sm me-3" alt="user2">
                                                        </div>
                                                        <div class="d-flex flex-column justify-content-center">
                                                            <h6 class="mb-0 text-sm"><?php echo e($row->plant_type); ?></h6>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-center">
                                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($row->address); ?></p>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-center">
                                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($row->land_area); ?></p>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-center">
                                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($row->number_of_support_device); ?> Support Devices</p>
                                                    </div>
                                                </td>
                                                <td class="align-middle text-center">
                                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($row->created_at); ?></span>
                                                </td>
                                                <td class="align-middle">
                                                    <div class="d-flex justify-content-center">

                                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Operator')): ?>

                                                            <form action="<?php echo e(route('field.delete', $row->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                                <button type="button" class="btn btn-link text-danger text-gradient px-3 mb-0 delete-btn"><i class="far fa-trash-alt me-2"></i>Delete</button>
                                                            </form>

                                                        <?php endif; ?>

                                                        <button class="btn btn-link detail-btn text-dark text-gradient px-3 mb-0">
                                                            <i class="fas fa-arrow-down me-2"></i>
                                                            <span>Detail</span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5" style="padding: 0;">
                                                    <div class="detail-elements" style="padding: 10px;">
                                                        <table style="width: 100%;">
                                                            <tr>
                                                                <td colspan="5" style="padding-left: 15px;">
                                                                    <a href="<?php echo e(route('client.field.detail.main', $row->id)); ?>">
                                                                        <div class="pb-1 pt-1 icon-move-right">
                                                                            <span style="margin-bottom: 0; font-size: 15px;" class="link-dark text-bold">Perangkat Utama</span>
                                                                            <button class="btn btn-link btn-icon-only btn-rounded btn-sm text-dark my-auto"><i class="ni ni-bold-right" aria-hidden="true"></i></button>
                                                                        </div>
                                                                    </a>
                                                                </td>
                                                            </tr>

                                                            <?php for($i = 0; $i < $row->number_of_support_device; $i++): ?>
                                                                <tr>
                                                                    <td colspan="5" style="padding-left: 15px;">
                                                                        <a href="<?php echo e(route('client.field.detail.support', ['id' => $row->id, 'number' => $i+1])); ?>">
                                                                            <div class="pb-1 pt-1 icon-move-right">
                                                                                <span style="margin-bottom: 0; font-size: 15px;" class="link-dark text-bold">Perangkat Pendukung <?php echo e($i+1); ?></span>
                                                                                <button class="btn btn-link btn-icon-only btn-rounded btn-sm text-dark my-auto"><i class="ni ni-bold-right" aria-hidden="true"></i></button>
                                                                            </div>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                            <?php endfor; ?>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>

<style>

    .detail-elements {
        display: none;
    }

</style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

<script>

    $('tr').on('click', '.delete-btn', function (e){
        e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "Field would be deleted",
            icon: "warning",
            type: "warning",
            buttons: ["Cancel","Yes!"],
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Delete!'
        }).then((willAccept) => {
            if (willAccept) {
                $(this).parent('form').trigger('submit')
            }
        });
    });

    $('tr').on('click', '.detail-btn', function() {
        $(this).closest('tr').next().find('.detail-elements').slideToggle(200, 'linear')
    });

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlantsGrowthChamberApp-arnesys\arnesys-web\resources\views/master/field/index.blade.php ENDPATH**/ ?>