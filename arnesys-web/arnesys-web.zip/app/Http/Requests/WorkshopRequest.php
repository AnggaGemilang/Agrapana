<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class WorkshopRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        return [
            "title" => "required",
            "image" => "required",
            "desc" => "required",
            "event_date" => "required",
            "registration_start_date" => "required",
            "registration_end_date" => "required",
            "first_presence_start_date" => "required",
            "first_presence_end_date" => "required",
            "second_presence_start_date" => "required",
            "second_presence_end_date" => "required"
        ];
    }
}
