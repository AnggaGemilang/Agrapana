package org.d3if4055.belajarfirebase.data

const val NODE_AUTHORS = "authors"